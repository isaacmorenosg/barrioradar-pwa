import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';

const root = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(root, 'public');
const dataDir = path.resolve(process.env.DATA_DIR || path.join(root, 'data'));
fs.mkdirSync(dataDir, { recursive: true });
const db = new DatabaseSync(path.join(dataDir, 'barrioradar.sqlite'));
db.exec(`PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS geocode_cache (query TEXT PRIMARY KEY, result TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS reviews (
  id TEXT PRIMARY KEY,
  actor_id TEXT NOT NULL,
  cell_id TEXT NOT NULL,
  cell_x REAL NOT NULL,
  cell_y REAL NOT NULL,
  day_score INTEGER NOT NULL CHECK(day_score BETWEEN 1 AND 5),
  night_score INTEGER NOT NULL CHECK(night_score BETWEEN 1 AND 5),
  light_score INTEGER NOT NULL CHECK(light_score BETWEEN 1 AND 5),
  noise_score INTEGER NOT NULL CHECK(noise_score BETWEEN 1 AND 5),
  tags TEXT NOT NULL DEFAULT '[]',
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
  created_at INTEGER NOT NULL,
  reviewed_at INTEGER,
  UNIQUE(actor_id, cell_id)
);
CREATE INDEX IF NOT EXISTS idx_reviews_public ON reviews(status,created_at,cell_x,cell_y);
CREATE INDEX IF NOT EXISTS idx_reviews_pending ON reviews(status,created_at);
`);

const HOST = process.env.HOST || '0.0.0.0';
const PORT = Number(process.env.PORT || 4173);
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || '';
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const ALLOWED_TAGS = new Set(['buena_iluminacion', 'poca_iluminacion', 'ambiente_tranquilo', 'ruido_nocturno', 'mucho_trafico', 'vida_en_la_calle', 'calles_solitarias']);
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json', '.svg':'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
const R = 6378137;
const CELL_RADIUS = 400;
const SQRT3 = Math.sqrt(3);
const limiter = new Map();
let lastGeocodeCall = 0;

function toMeters(lat, lng) {
  return {x:R*lng*Math.PI/180,y:R*Math.log(Math.tan(Math.PI/4+lat*Math.PI/360))};
}
function axial(x, y) {
  const q = (SQRT3/3*x-y/3)/CELL_RADIUS;
  const r = (2/3*y)/CELL_RADIUS;
  let cx=q, cz=r, cy=-cx-cz;
  let rx=Math.round(cx), ry=Math.round(cy), rz=Math.round(cz);
  const dx=Math.abs(rx-cx),dy=Math.abs(ry-cy),dz=Math.abs(rz-cz);
  if(dx>dy && dx>dz) rx=-ry-rz;
  else if(dy>dz) ry=-rx-rz;
  else rz=-rx-ry;
  return {q:rx,r:rz};
}
function cellCenter(q,r) {return {x:CELL_RADIUS*SQRT3*(q+r/2),y:CELL_RADIUS*1.5*r};}
function json(res,status,value,otherHeaders={}) {
  const out=JSON.stringify(value);
  res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...otherHeaders});
  res.end(out);
}
function identity(req,res) {
  const cookie=(req.headers.cookie||'').split(';').map(c=>c.trim()).find(c=>c.startsWith('br_sid='))?.slice(7);
  let id;
  if(cookie) {
    const [candidate,sig]=cookie.split('.');
    if(candidate&&sig&&/^[a-f0-9-]{36}$/.test(candidate)) {
      const expected=crypto.createHmac('sha256',SESSION_SECRET).update(candidate).digest('hex');
      if(sig.length===expected.length && crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected))) id=candidate;
    }
  }
  if(!id) {
    id=crypto.randomUUID();
    const signature=crypto.createHmac('sha256',SESSION_SECRET).update(id).digest('hex');
    const secure=req.socket.encrypted||req.headers['x-forwarded-proto']==='https' ? '; Secure' : '';
    res.setHeader('Set-Cookie',`br_sid=${id}.${signature}; HttpOnly; SameSite=Lax; Path=/; Max-Age=31536000${secure}`);
  }
  return crypto.createHmac('sha256',SESSION_SECRET).update(id).digest('hex');
}
async function readBody(req) {
  let size=0;const chunks=[];
  for await(const chunk of req) {
    size+=chunk.length;
    if(size>8192) throw new Error('El envio es demasiado grande');
    chunks.push(chunk);
  }
  try{return JSON.parse(Buffer.concat(chunks).toString('utf-8'));}
  catch{throw new Error('JSON no valido');}
}
function rateLimit(req,operation,max=15,windowMs=60000) {
  const ip=process.env.TRUST_PROXY==='1' ? String(req.headers['x-forwarded-for']||req.socket.remoteAddress||'unknown').split(',')[0].trim() : String(req.socket.remoteAddress||'unknown');
  const key=`${ip}:${operation}`;
  const now=Date.now();
  if(limiter.size>10000) limiter.clear();
  const state=limiter.get(key);
  if(!state||now>state.until){limiter.set(key,{count:1,until:now+windowMs});return true;}
  if(state.count>=max)return false;
  state.count++;
  return true;
}
function isAdmin(req){return !!ADMIN_TOKEN && req.headers.authorization===`Bearer ${ADMIN_TOKEN}`;}
function securityHeaders(res) {
  res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');
  res.setHeader('X-Frame-Options','SAMEORIGIN');
  res.setHeader('Permissions-Policy','camera=(), microphone=()');
}
const server=http.createServer(async (req,res)=>{
  try {
    securityHeaders(res);
    const url=new URL(req.url||'/',`http://${req.headers.host||'localhost'}`);
    const pathname=url.pathname;
    if(pathname==='/api/health')return json(res,200,{ok:true,service:'BarrioRadar',mode:'comunidad'});
    if(pathname==='/api/session'&&req.method==='POST'){
      identity(req,res);
      return json(res,200,{ok:true});
    }
    if(pathname==='/api/geocode'&&req.method==='GET'){
      if(!rateLimit(req,'geocode',12,3600000))return json(res,429,{error:'Limite de busquedas alcanzado'});
      const query=String(url.searchParams.get('q')||'').trim().slice(0,120);
      if(query.length<2)return json(res,400,{error:'Introduce una localidad o direccion'});
      const cacheKey=query.toLocaleLowerCase('es');
      const cached=db.prepare('SELECT result,created_at FROM geocode_cache WHERE query=?').get(cacheKey);
      if(cached && Date.now()-cached.created_at<7*86400000)return json(res,200,JSON.parse(cached.result));
      if(Date.now()-lastGeocodeCall<1100)return json(res,429,{error:'Prueba de nuevo en unos segundos'});
      lastGeocodeCall=Date.now();
      let response;
      try{
        const service=process.env.GEOCODER_URL||'https://photon.komoot.io/api/';
        const endpoint=new URL(service);
        endpoint.searchParams.set('q',query);
        endpoint.searchParams.set('limit','5');
        endpoint.searchParams.set('lang','es');
        endpoint.searchParams.set('bbox','-18.5,27,5,44.5');
        response=await fetch(endpoint,{headers:{'User-Agent':'BarrioRadar/0.1 (community prototype; admin@localhost.invalid)'},signal:AbortSignal.timeout(7000)});
        if(!response.ok)throw new Error('Servicio no disponible');
      }catch{return json(res,503,{error:'Busqueda externa no disponible. Prueba con una ciudad sugerida.'});}
      const result=await response.json();
      const places=(result.features||[]).filter(f=>String(f.properties?.countrycode||'').toUpperCase()==='ES').slice(0,4).map(f=>({
        lat:f.geometry.coordinates[1],lng:f.geometry.coordinates[0],
        name:[f.properties.name,f.properties.city||f.properties.county].filter((part,i,arr)=>part&&arr.indexOf(part)===i).join(', ')
      }));
      const payload={places};
      db.prepare('INSERT INTO geocode_cache(query,result,created_at) VALUES(?,?,?) ON CONFLICT(query) DO UPDATE SET result=excluded.result,created_at=excluded.created_at').run(cacheKey,JSON.stringify(payload),Date.now());
      return json(res,200,payload);
    }
    if(pathname==='/api/ratings'&&req.method==='GET'){
      if(!rateLimit(req,'read',80))return json(res,429,{error:'Demasiadas consultas'});
      const bbox=(url.searchParams.get('bbox')||'').split(',').map(Number);
      if(bbox.length!==4||bbox.some(v=>!Number.isFinite(v)))return json(res,400,{error:'bbox invalido'});
      let [west,south,east,north]=bbox;
      if(west< -19||east>6||south<27||north>45||east<=west||north<=south)return json(res,400,{error:'Fuera del area admitida'});
      const sw=toMeters(south,west),ne=toMeters(north,east);
      const since=Date.now()-180*86400000;
      const rows=db.prepare(`SELECT cell_id AS id, cell_x AS x,cell_y AS y,COUNT(DISTINCT actor_id) AS count,
        ROUND(AVG(day_score),2) AS day,ROUND(AVG(night_score),2) AS night,
        ROUND(AVG(light_score),2) AS light,ROUND(AVG(noise_score),2) AS noise
        FROM reviews WHERE status='approved' AND created_at >= ?
        AND cell_x BETWEEN ? AND ? AND cell_y BETWEEN ? AND ?
        GROUP BY cell_id HAVING COUNT(DISTINCT actor_id)>=5 LIMIT 500`)
        .all(since,sw.x-1500,ne.x+1500,sw.y-1500,ne.y+1500);
      return json(res,200,{cells:rows,minimum:5,days:180,source:'Aportaciones comunitarias moderadas'});
    }
    if(pathname==='/api/reviews'&&req.method==='POST'){
      if(!rateLimit(req,'write',10,3600000))return json(res,429,{error:'Has alcanzado el limite de aportaciones por ahora'});
      if(!(req.headers['content-type']||'').includes('application/json'))return json(res,415,{error:'Formato no valido'});
      const actor=identity(req,res),body=await readBody(req);
      const lat=Number(body.lat),lng=Number(body.lng);
      const scores=['day','night','light','noise'].map(key=>body[key]);
      const tags=body.tags;
      if(!Number.isFinite(lat)||!Number.isFinite(lng)||lat<27||lat>44.5||lng< -18.5||lng>5||
         scores.some(v=>!Number.isInteger(v)||v<1||v>5)||!Array.isArray(tags)||tags.length>4||tags.some(t=>!ALLOWED_TAGS.has(t)))
        return json(res,400,{error:'Revisa los datos de tu valoracion'});
      const {q,r}=axial(...Object.values(toMeters(lat,lng)));
      const id=`${q}:${r}`;
      if(body.cellId!==id)return json(res,400,{error:'La zona no coincide con las coordenadas'});
      const center=cellCenter(q,r);
      const now=Date.now();
      const existing=db.prepare('SELECT id FROM reviews WHERE actor_id=? AND cell_id=?').get(actor,id);
      if(!existing) {
        const recent=db.prepare('SELECT COUNT(*) AS n FROM reviews WHERE actor_id=? AND created_at>?').get(actor,now-86400000);
        if(recent.n>=10)return json(res,429,{error:'Has alcanzado el limite diario de zonas'});
      }
      db.prepare(`INSERT INTO reviews (id,actor_id,cell_id,cell_x,cell_y,day_score,night_score,light_score,noise_score,tags,status,created_at,reviewed_at)
       VALUES(?,?,?,?,?,?,?,?,?,?,'pending',?,NULL)
       ON CONFLICT(actor_id,cell_id) DO UPDATE SET day_score=excluded.day_score,night_score=excluded.night_score,light_score=excluded.light_score,
       noise_score=excluded.noise_score,tags=excluded.tags,status='pending',created_at=excluded.created_at,reviewed_at=NULL`)
        .run(existing?.id||crypto.randomUUID(),actor,id,center.x,center.y,...scores,JSON.stringify([...new Set(tags)]),now);
      return json(res,201,{ok:true,status:'pending',message:'Valoracion recibida. Sera visible cuando se modere y haya suficientes aportaciones independientes.'});
    }
    if(pathname==='/api/admin/queue'&&req.method==='GET'){
      if(!isAdmin(req))return json(res,401,{error:'Acceso restringido'});
      const rows=db.prepare('SELECT id,cell_id,day_score,night_score,light_score,noise_score,tags,created_at FROM reviews WHERE status=? ORDER BY created_at ASC LIMIT 100').all('pending');
      return json(res,200,{rows});
    }
    if(pathname==='/api/admin/moderate'&&req.method==='POST'){
      if(!isAdmin(req))return json(res,401,{error:'Acceso restringido'});
      const body=await readBody(req);
      if(typeof body.id!=='string'||!['approved','rejected'].includes(body.status))return json(res,400,{error:'Datos no validos'});
      const result=db.prepare("UPDATE reviews SET status=?,reviewed_at=? WHERE id=? AND status='pending'").run(body.status,Date.now(),body.id);
      return json(res,result.changes?200:404,{ok:result.changes===1});
    }
    if(req.method!=='GET'&&req.method!=='HEAD')return json(res,405,{error:'Metodo no permitido'});
    const normalized=path.posix.normalize(decodeURIComponent(pathname));
    const requested=normalized==='/'?'/index.html':normalized;
    if(!/^\/[a-zA-Z0-9_./-]+$/.test(requested)||requested.includes('..'))return json(res,404,{error:'No encontrado'});
    const realPath=path.resolve(publicDir,'.'+requested);
    if(!realPath.startsWith(publicDir+path.sep))return json(res,403,{error:'Prohibido'});
    let stat;
    try{stat=fs.statSync(realPath);}catch{return json(res,404,{error:'No encontrado'});}
    if(!stat.isFile())return json(res,404,{error:'No encontrado'});
    const ext=path.extname(realPath);
    const caching=/\.(png|svg)$/.test(ext)?'public, max-age=86400':'no-cache';
    res.writeHead(200,{'Content-Type':MIME[ext]||'application/octet-stream','Cache-Control':caching});
    if(req.method==='HEAD')return res.end();
    fs.createReadStream(realPath).pipe(res);
  }catch(err){
    console.error('[BarrioRadar]',err);
    if(!res.headersSent)json(res,400,{error:err.message||'Error inesperado'});
    else res.end();
  }
});
server.listen(PORT,HOST,()=>console.log(`BarrioRadar listo en http://localhost:${PORT}`));
