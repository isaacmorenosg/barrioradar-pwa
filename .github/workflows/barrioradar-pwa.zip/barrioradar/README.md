# BarrioRadar - PWA para explorar percepciones vecinales en Espana

**MVP funcional, 18 de octubre de 2026.** Una web app instalable, responsive y sin dependencias de npm. Incluye un servidor real de Node.js con SQLite, voto estructurado, moderacion, agregacion anonima y mapa interactivo basado en OpenStreetMap. No se ha desplegado en un dominio publico ni cuenta con usuarios reales.

> **AVISO IMPORTANTE:** al abrir la app se activa el MODO DEMO, con opiniones y notas completamente inventadas para evaluar el aspecto y la experiencia de uso. El aviso de demostracion permanece visible. Desactivalo en el interruptor **Modo demo** para ver SOLO aportaciones reales moderadas. Ninguna zona del mapa debe considerarse realmente peligrosa o segura por las notas demo.

## Arrancar en tu equipo

Requisitos: **Node.js 22 o superior**. No hace falta instalar paquetes.

```bash
cd barrioradar
node server.mjs
```

Abre **http://localhost:4173**. En otro equipo de la red, configura HOST y expone el puerto de forma segura. Para publicarla como PWA instalable fuera del equipo, publica bajo **HTTPS**.

Para las pruebas automaticas:

```bash
npm test
```

En el servidor privado puedes utilizar `docker compose up -d --build`, previa definicion de `SESSION_SECRET` y `ADMIN_TOKEN` en el entorno. El puerto solo se vincula a 127.0.0.1 en el ejemplo Compose: coloca un proxy inverso con HTTPS delante.

## Que hace

- Busca entre 30+ ciudades de Espana sin consumir geocodificacion externa; tambien permite realizar una busqueda explicita de otras localidades mediante Photon (sin autocompletado).
- Mapa OSM desplazable/zoom, hexagonos geograficos, comparacion dia/noche y fichas de zona.
- Modo demo claramente etiquetado, con cifras y colores simulados; modo real sin datos inventados.
- Opiniones ciudadanas **sin texto libre** para reducir acusaciones personales, rumores y sesgos: valoraciones de dia, noche, iluminacion y confort acustico, mas etiquetas predefinidas.
- Cada sesion anonima tiene un voto por hexagono. Re-votar reemplaza el voto previo y lo devuelve a moderacion.
- Cola de moderacion manual, accesible a `/admin.html` con ADMIN_TOKEN, para aprobar o rechazar respuestas.
- Una celda solo aparece en el mapa REAL si acumula al menos **cinco identidades anonimas diferentes** aprobadas en los **ultimos 180 dias**.
- Contadores, comparador de dos sectores (instantaneas de ultima consulta), tres zonas guardadas en localStorage.
- PWA instalable: manifest, iconos 192 y 512, servicio worker; interfaz disponible tras cargarla, pero mapa y datos en linea requieren Internet.
- Version responsive, sin GPS obligatorio. Localizacion aproximada opcional si el usuario la permite.

## Moderacion: acceder al panel

1. Configura `ADMIN_TOKEN` como variable de entorno antes de iniciar. Si no se define, la aprobacion esta deshabilitada y todas las aportaciones permanecen pendientes.
2. Abre `https://TU-DOMINIO/admin.html` y pega el token.
3. Aprueba o rechaza cada aportacion; despues de alcanzar cinco votos aprobados de diferentes sesiones, el sector aparecera en modo REAL.
4. Protege `admin.html` con acceso de red o autenticacion adicional en produccion; el token de administrador no se guarda en el navegador.

**Seguridad MVP, no para un lanzamiento publico masivo:** las cookies anonimas estan firmadas, son HttpOnly, SameSite=Lax y Secure bajo HTTPS. El limitador por IP es simple y usa memoria local, no es distribuido. Se conserva solo el hash de una sesion anonima con su voto por celda, sin nombres ni posicion exacta. Un usuario que borra cookies puede crear otra identidad, por lo que el umbral de cinco **no prueba** que hayan participado cinco personas fisicas diferentes. Antes de publicarla hace falta autenticacion con cuenta verificada, control contra votos coordinados, panel profesional de moderacion, politicas de privacidad/cookies aplicables, RGPD, recuperacion ante abusos, backups y auditoria.

## Arquitectura

```text
public/index.html          SPA responsive
public/styles.css          Diseno adaptativo
public/app.js              Mapa propio (Web Mercator + hex), votos, guardados, comparador
public/sw.js               PWA offline shell (no descarga de teselas)
public/manifest.webmanifest
public/icons/              Iconos PNG instalables
public/admin.html + admin.js
server.mjs                 Servidor HTTP sin dependencias + API REST + SQLite
README.md                  Manual
Dockerfile / docker-compose.yml
```

### API

| Metodo | Ruta | Uso |
|---|---|---|
| GET | `/api/health` | Estado |
| GET | `/api/ratings?bbox=oeste,sur,este,norte` | Agregados publicos >=5 recientes |
| GET | `/api/geocode?q=...` | Busqueda explicitamente solicitada con cache a 7 dias y limites |
| POST | `/api/reviews` | Envio de voto a moderacion (cookie anonima) |
| POST | `/api/session` | Iniciar sesion de cookie opcionalmente |
| GET | `/api/admin/queue` | Cola, autorizacion Bearer ADMIN_TOKEN |
| POST | `/api/admin/moderate` | Aprobar/rechazar, autorizacion Bearer ADMIN_TOKEN |

Ejemplo de voto:

```json
{
  "lat": 37.3891,
  "lng": -5.9845,
  "cellId": "ID_DEL_HEXAGONO_CALCULADO_POR_LA_APP",
  "day": 4,
  "night": 3,
  "light": 4,
  "noise": 3,
  "tags": ["buena_iluminacion", "ambiente_tranquilo"]
}
```

### Como interpreta los colores

Las notas son **percepciones subjetivas** de seguridad al caminar, que no equivalen a una tasa de criminalidad ni estan contrastadas con denuncias. Con un minimo de 5 aportaciones moderadas, el promedio se agrupa en tres categorias:

- Desde 3,7/5: mas tranquilidad percibida.
- Desde 2,8 hasta 3,69: opiniones mixtas.
- Menos de 2,8: mas reservas percibidas.

Una zona SIN DATOS nunca se pinta verde. El nombre del sector es un identificador neutro de una cuadricula aproximada, no una division oficial ni una etiqueta de barrio. La seleccion de participantes puede ser sesgada, de modo que incluso valores con 25 personas no son una estimacion representativa de toda una zona.

## Fuentes y condiciones

- Estadisticas oficiales: [Portal Estadistico de Criminalidad - Ministerio del Interior](https://estadisticasdecriminalidad.ses.mir.es/publico/portalestadistico/balances.html). Los balances pueden informar sobre municipios (por ejemplo >20.000 habitantes), pero **no se asignan a las celdas del mapa**. Una capa futura con datos oficiales deberia tener su propia geometria, periodo y fuente.
- Cartografia: [OpenStreetMap](https://www.openstreetmap.org/copyright), proveedor publico de teselas bajo [politica de uso](https://operations.osmfoundation.org/policies/tiles/). La app carga solo las teselas visibles, deja la atribucion en pantalla, respeta cache HTTP y NO permite descarga offline de mapas. Para escalar usa un proveedor comercial/propio de teselas OSM.
- Geocodificacion para busquedas no precargadas: [Photon](https://github.com/komoot/photon), servicio demo de komoot para uso moderado, sin SLA. Consultas solo al enviar busqueda, cache local servidor de 7 dias, limite por servidor 1 solicitud/1,1 s, sin autocomplete. Para un lanzamiento a escala debe sustituirse por un servicio contratado o propio. No se utiliza Nominatim publico.

## Modelo comercial sugerido (NO COBRADO NI HABILITADO)

- **Gratis:** explorar, votar, guardar 3 zonas y comparar 2 zonas.
- **Informe unico (~4,90 EUR, propuesta):** comparar entornos de 1-3 viviendas, evolucion y checklist de visita. Solo se vende si existe volumen y calidad de datos suficientes.
- **Plan Pro (~3,90 EUR/mes, propuesta):** vigilancia de zonas guardadas, cambios importantes y comparativas frecuentes para personas en busqueda de vivienda. Pagos, alertas y reportes estan marcados *proximamente*, NO estan implementados.

**Siguiente paso antes de lanzamiento**: autenticacion real, antispam y proteccion frente a manipulaciones; politica de publicacion, control de reputacion y derecho de rectificacion; resolver percepciones sesgadas; publicar mapa real sin simulaciones por defecto; adaptar proveedor de cartografia; ensayar accesibilidad con herramientas especializadas y usuarios.
