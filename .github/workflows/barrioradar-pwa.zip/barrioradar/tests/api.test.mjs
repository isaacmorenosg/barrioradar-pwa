import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import net from 'node:net';

const ROOT=path.resolve('.');
const R=6378137, HEX=400, SQRT3=Math.sqrt(3);
function coords(lat,lng){const x=R*lng*Math.PI/180,y=R*Math.log(Math.tan(Math.PI/4+lat*Math.PI/360));const q=(SQRT3/3*x-y/3)/HEX,r=(2/3*y)/HEX;let a=Math.round(q),c=Math.round(r),b=Math.round(-q-r);const dx=Math.abs(a-q),dy=Math.abs(b+q+r),dz=Math.abs(c-r);if(dx>dy&&dx>dz)a=-b-c;else if(dy>dz)b=-a-c;else c=-a-b;const mx=HEX*SQRT3*(a+c/2),my=HEX*1.5*c;return{cellId:`${a}:${c}`,lat:(2*Math.atan(Math.exp(my/R))-Math.PI/2)*180/Math.PI,lng:mx/R*180/Math.PI};}
function getPort(){return new Promise((resolve,reject)=>{const server=net.createServer();server.once('error',reject);server.listen(0,'127.0.0.1',()=>{const port=server.address().port;server.close(()=>resolve(port));});});}
async function waitFor(url){for(let i=0;i<60;i++){try{const r=await fetch(url+'/api/health');if(r.ok)return;}catch{}await new Promise(r=>setTimeout(r,80));}throw new Error('Server startup timed out');}
test('safe aggregate, moderation and single vote per actor',async()=>{
  const dir=mkdtempSync(path.join(os.tmpdir(),'br-test-'));
  const port=await getPort();const base=`http://127.0.0.1:${port}`;
  const child=spawn(process.execPath,['server.mjs'],{cwd:ROOT,env:{...process.env,PORT:String(port),DATA_DIR:dir,ADMIN_TOKEN:'sample-admin-token',SESSION_SECRET:'test-secret-at-least-32-chars-long',NODE_NO_WARNINGS:'1'},stdio:'ignore'});
  try{
    await waitFor(base);
    let r=await fetch(base+'/api/health');assert.equal(r.status,200);
    r=await fetch(base+'/api/ratings?bbox=bad');assert.equal(r.status,400);
    r=await fetch(base+'/api/admin/queue');assert.equal(r.status,401);
    const {lat,lng,cellId}=coords(37.3891,-5.9845);
    const data={cellId,lat,lng,day:5,night:3,light:4,noise:2,tags:['buena_iluminacion']};
    const bbox='-6.1,37.3,-5.8,37.5';
    const cookies=[];
    for(let i=0;i<4;i++){
      r=await fetch(base+'/api/reviews',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...data,night:i+1})});
      assert.equal(r.status,201);cookies.push(r.headers.get('set-cookie').split(';')[0]);
    }
    r=await fetch(base+'/api/ratings?bbox='+bbox);assert.equal((await r.json()).cells.length,0,'Fewer than 5 must not appear');
    r=await fetch(base+'/api/reviews',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
    assert.equal(r.status,201);cookies.push(r.headers.get('set-cookie').split(';')[0]);
    const auth={'Authorization':'Bearer sample-admin-token'};
    r=await fetch(base+'/api/admin/queue',{headers:auth});assert.equal((await r.json()).rows.length,5);
    const pending=await (await fetch(base+'/api/admin/queue',{headers:auth})).json();
    for(const row of pending.rows){
      r=await fetch(base+'/api/admin/moderate',{method:'POST',headers:{...auth,'Content-Type':'application/json'},body:JSON.stringify({id:row.id,status:'approved'})});
      assert.equal(r.status,200);
    }
    r=await fetch(base+'/api/ratings?bbox='+bbox);let body=await r.json();
    assert.equal(body.cells.length,1);assert.equal(body.cells[0].count,5);
    assert.equal(body.cells[0].id,cellId);assert.equal(body.cells[0].day,5);
    r=await fetch(base+'/api/reviews',{method:'POST',headers:{'Content-Type':'application/json','Cookie':cookies[0]},body:JSON.stringify({...data,night:5})});
    assert.equal(r.status,201);
    r=await fetch(base+'/api/ratings?bbox='+bbox);body=await r.json();assert.equal(body.cells.length,0,'A changed vote requires re-moderation');
    r=await fetch(base+'/api/reviews',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...data,light:42})});
    assert.equal(r.status,400);
    r=await fetch(base+'/api/reviews',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...data,cellId:'999:999'})});
    assert.equal(r.status,400);
  }finally{child.kill('SIGTERM');rmSync(dir,{recursive:true,force:true});}
});
