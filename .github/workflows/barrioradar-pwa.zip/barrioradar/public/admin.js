/* Moderation is checked server-side via auth.uid() + br_moderators. */
const $ = id => document.getElementById(id);
const escapeHTML = s => String(s).replace(/[&<>"']/g, x => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
async function loadQueue() {
  const api = window.BarrioAPI;
  if (!api?.configured) { $('message').textContent = 'Supabase todavia no esta configurado.'; return; }
  const user = await api.currentAdmin();
  if (!user) { $('message').textContent = 'Accede con tu cuenta de moderador.'; return; }
  $('adminAccount').textContent = `Sesion: ${user.email || 'Cuenta'} | UUID: ${user.id}. Este UUID debe estar autorizado en br_moderators.`;
  try {
    const rows = await api.adminQueue();
    $('message').textContent = `${rows.length} aportaciones pendientes`;
    $('board').innerHTML = rows.length ? rows.map(r => `
      <div class="card">
        <h3>Sector ${escapeHTML(r.cell_id)}</h3>
        <p class="small">Enviado: ${new Date(r.created_at).toLocaleString('es-ES')}</p>
        <div class="chips">
          <span class="chip">Dia ${r.day_score}/5</span>
          <span class="chip">Noche ${r.night_score}/5</span>
          <span class="chip">Luz ${r.light_score}/5</span>
          <span class="chip">Acustica ${r.noise_score}/5</span>
        </div>
        <p>Observaciones: ${escapeHTML((Array.isArray(r.tags) ? r.tags : []).join(', ') || 'Sin etiquetas')}</p>
        <div class="actions">
          <button data-id="${escapeHTML(r.id)}" data-action="approved">Aprobar</button>
          <button class="reject" data-id="${escapeHTML(r.id)}" data-action="rejected">Rechazar</button>
        </div>
      </div>`).join('') : '<div class="empty">No quedan aportaciones pendientes.</div>';
    document.querySelectorAll('[data-action]').forEach(btn => btn.addEventListener('click', () => moderate(btn)));
  } catch (err) { $('message').textContent = err.message || 'No se pudo acceder a la cola.'; }
}
async function moderate(btn) {
  btn.disabled = true;
  try {
    await window.BarrioAPI.moderate(btn.dataset.id, btn.dataset.action);
    await loadQueue();
  } catch (err) { $('message').textContent = err.message; btn.disabled = false; }
}
$('login').addEventListener('submit', async e => {
  e.preventDefault();
  const btn = e.target.querySelector('button'); btn.disabled = true;
  try {
    const email = $('email').value.trim();
    await window.BarrioAPI.sendLoginEmail(email);
    $('codeEmail').value = email;
    $('message').textContent = 'Hemos solicitado un enlace de acceso. Comprueba tu correo y vuelve aqui; si recibes un codigo, introducelo abajo.';
  } catch (err) { $('message').textContent = err.message || 'No se pudo solicitar acceso.'; }
  finally { btn.disabled = false; }
});
$('codeLogin').addEventListener('submit', async e => {
  e.preventDefault();
  const btn=e.target.querySelector('button'); btn.disabled=true;
  try {
    await window.BarrioAPI.confirmEmailCode($('codeEmail').value.trim(), $('code').value.trim());
    $('code').value='';
    await loadQueue();
  } catch (err) { $('message').textContent=err.message || 'Codigo incorrecto.'; }
  finally { btn.disabled=false; }
});
if (window.BarrioAPI?.configured) window.BarrioAPI.onCommunityAuthChange(loadQueue);
loadQueue();
