let secret='';
const $=id=>document.getElementById(id);
const escapeHTML=s=>String(s).replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\'':'&#39;'}[x]));
async function loadQueue(){
  try{
    const res=await fetch('/api/admin/queue',{headers:{Authorization:`Bearer ${secret}`},cache:'no-store'});
    if(!res.ok)throw new Error('Token incorrecto o panel sin configurar');
    const {rows}=await res.json();
    $('message').textContent=`${rows.length} aportaciones pendientes`;
    $('board').innerHTML=rows.length?rows.map(r=>`<div class="card"><h3>Sector ${escapeHTML(r.cell_id)}</h3><p class="small">Enviado: ${new Date(r.created_at).toLocaleString('es-ES')}</p><div class="chips"><span class="chip">Día ${r.day_score}/5</span><span class="chip">Noche ${r.night_score}/5</span><span class="chip">Luz ${r.light_score}/5</span><span class="chip">Acústica ${r.noise_score}/5</span></div><p>Observaciones: ${escapeHTML(JSON.parse(r.tags).join(', ')||'Sin etiquetas')}</p><div class="actions"><button data-id="${r.id}" data-action="approved">Aprobar</button><button class="reject" data-id="${r.id}" data-action="rejected">Rechazar</button></div></div>`).join(''):'<div class="empty">No quedan aportaciones pendientes.</div>';
    document.querySelectorAll('[data-action]').forEach(btn=>btn.addEventListener('click',()=>moderate(btn)));
  }catch(e){$('message').textContent=e.message;}
}
async function moderate(btn){
  btn.disabled=true;
  const res=await fetch('/api/admin/moderate',{method:'POST',headers:{Authorization:`Bearer ${secret}`,'Content-Type':'application/json'},body:JSON.stringify({id:btn.dataset.id,status:btn.dataset.action})});
  if(!res.ok){$('message').textContent='No se pudo moderar';btn.disabled=false;return;}
  await loadQueue();
}
$('login').addEventListener('submit',e=>{e.preventDefault();secret=$('token').value;$('token').value='';loadQueue();});
